Merge List

Write a Python program to Zip two given lists of lists.



Input:

m : row size

n: column size

list1 and list 2 :  Two lists

Output

Zipped List : List which combined both list1 and list2



Sample test case



Sample input

2

2

1 

3

5

7

2

4

6

8



Sample Output



[[1, 3, 2, 4], [5, 7, 6, 8]]



def zip_lists(list1, list2):

    return [row1 + row2 for row1, row2 in zip(list1, list2)]

 

def main():

    m = int(input())

    n = int(input())

 

 

    list1 = [[int(input()) for _ in range(n)] for _ in range(m)]

    list2 = [[int(input()) for _ in range(n)] for _ in range(m)]

 

    zipped_list = zip_lists(list1, list2)

    print(zipped_list)

