Count Elements

Complete the program to count frequency of each element of an array. Frequency of a particular element will be printed once.

Sample Test Cases

 Test Case 1

 Input

 7

23

45

23

56

45

23

40

 Output

 23 occurs 3 times

45 occurs 2 times

56 occurs 1 times

40 occurs 1 times

 

import collections 

def CountFrequency(arr):

	return collections.Counter(arr)

 

if __name__ == "__main__":

	# Input size of array

	n = int(input())

	

	# Input elements in array

	arr = []

	for _ in range(n):

    	ele = int(input())

    	arr.append(ele)

	

	# Calculate frequency of each element

	freq = CountFrequency(arr)

 

 

	for key, value in freq.items():

    	print(f"{key} occurs {value} times")

