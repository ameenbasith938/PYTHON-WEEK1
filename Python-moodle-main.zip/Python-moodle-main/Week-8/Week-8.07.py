American keyboard

Given an array of strings words, return the words that can be typed using letters of the alphabet on only one row of American keyboard like the image below.

In the American keyboard:

●	the first row consists of the characters "qwertyuiop",

●	the second row consists of the characters "asdfghjkl", and

●	the third row consists of the characters "zxcvbnm"

 



Example 1:

Input: words = ["Hello","Alaska","Dad","Peace"]

Output: ["Alaska","Dad"]

Example 2:

Input: words = ["omk"]

Output: []

Example 3:

Input: words = ["adsdf","sfd"]

Output: ["adsdf","sfd"]





For example:

Input	Result

4

Hello

Alaska

Dad

Peace	Alaska

Dad



def findWords(words):

    row1 = set('qwertyuiop')

    row2 = set('asdfghjkl')

    row3 = set('zxcvbnm')

    

    result = []

    for word in words:

        w = set(word.lower())

        if w.issubset(row1) or w.issubset(row2) or w.issubset(row3):

            result.append(word)

    if len(result) == 0:

        print("No words")

    else:

        for i in result:

            print(i)    



a = int(input())

arr = [input() for i in range(a)]

findWords(arr)

