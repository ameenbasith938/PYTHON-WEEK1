Next Perfect Square

Given a number N, find the next perfect square greater than N.

Input Format:

Integer input from stdin.

Output Format:

Perfect square greater than N.

Example Input:

10

Output:

16



a=int(input())

c=[]

for i in range(0,a):

    b=i**2

    if(b>a):

        c.append(b)

print(c[0])
