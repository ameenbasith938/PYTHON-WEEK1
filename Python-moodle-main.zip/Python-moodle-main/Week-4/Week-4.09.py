Product of single digit

Given a positive integer N, check whether it can be represented as a product of single digit numbers.

Input Format:

Single Integer input.

Output Format:

Output displays Yes if condition satisfies else prints No.

Example Input:

14

Output:

Yes

Example Input:

13

Output:

No





a=int(input())

flag=0

for i in range(10):

    for j in range(10):

        if(i*j==a):

            flag=1

            break

if(flag==1):

    print("Yes")

else:

    print("No")



