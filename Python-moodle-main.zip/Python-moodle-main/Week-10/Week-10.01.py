Merge Sort

Write a Python program to sort a list of elements using the merge sort algorithm.



For example:

Input	Result

5

6 5 4 3 8

	3 4 5 6 8





a=int(input())

l=[]

l.extend(input().split())

for i in range(a-1):

    for j in range(a-1):

        if(int(l[j])>int(l[j+1])):

            t=int(l[j])

            l[j]=int(l[j+1])

            l[j+1]=t

for i in range(a):

    print(int(l[i]),end=" ")


