Binary Search

Write a Python program for binary search.



For example:

Input	Result

1 2 3 5 8

6	False

3 5 9 45 42

42	True





a = input().split(",")

b = input()

print(b in a)
