Remove Palindrome Words

String should contain only the words are not palindrome.



Sample Input 1

Malayalam is my mother tongue



Sample Output 1

is my mother tongue



For example:



 



a=[]

a=input()

b=a. split()

for i in b:

    k=i.lower()

    if k!=k[::-1]:

         print(k,end=' ')

