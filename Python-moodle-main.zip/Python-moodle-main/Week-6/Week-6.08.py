String characters balance Test



Write a program to check if two strings are balanced. For example, strings s1 and s2 are balanced if all the characters in the s1 are present in s2. The character’s position doesn’t matter. If balanced display as "true" ,otherwise "false".



For example:



Input	Result

Yn

PYnative

True



a=input()

b=input()

if a in b:

    print("True")

else:

    print("False")





