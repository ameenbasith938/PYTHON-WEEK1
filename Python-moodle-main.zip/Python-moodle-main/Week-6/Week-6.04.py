Remove Characters

Given two Strings s1 and s2, remove all the characters from s1 which is present in s2.



Constraints

1<= string length <= 200

Sample Input 1

experience

enc



Sample Output 1

xpri





def remove_chars(s1, s2):

    return ''.join([char for char in s1 if char not in s2])

s1=input()

s2=input()

result = remove_chars(s1, s2)

print(result)



